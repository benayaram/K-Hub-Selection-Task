import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/visualize', methods=['POST'])
def visualize():
    if 'data_file' in request.files:
        data_file = request.files['data_file']
        # Check if the file is empty
        if data_file.filename == '':
            return "Error: No file selected."
        try:
            data = pd.read_csv(data_file, encoding='latin-1')
            data = data.dropna(subset=['x', 'y'])
            if data.empty:
                return "Error: The uploaded file is empty or contains no valid data."

            sample_data = data.to_dict(orient='records')

            return render_template('visualization.html', data=sample_data)
        except pd.errors.EmptyDataError:
            return "Error: The uploaded file is empty."
        except pd.errors.ParserError:
            return "Error: Invalid file format. Please upload a valid CSV file."
    else:
        return "Error: No file selected or invalid file format."


if __name__ == '__main__':
    app.run(debug=True)
